<?php
print_r($_SESSION);

echo"<h1> Home Page </h1>";